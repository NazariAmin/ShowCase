//
//  SliderViewController.swift
//  Showcase
//
//  Created by Wasim Ahmad on 2/1/17.
//  Copyright © 2017 Wasim Ahmad. All rights reserved.
//

import UIKit

class SliderViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

